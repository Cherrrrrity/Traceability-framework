import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 文件路径
output_paths = [
    '/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/matrix/output/[1]pft2-output.csv',
    '/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/matrix/output/[1]pft4-output.csv',
    '/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/matrix/output/[1]pft1-output.csv',
    '/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/matrix/output/[1]pft3-output.csv',
    '/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/matrix/output/[1]pft5-output.csv'
]

# 扩展和填充数据框的函数
def extend_and_fill(output_data, rows_to_fill):
    current_rows = output_data.shape[0]
    rows_to_add = rows_to_fill - current_rows
    if rows_to_add > 0:
        extra_data = pd.DataFrame(np.zeros((rows_to_add, output_data.shape[1])), columns=output_data.columns)
        extended_data = pd.concat([output_data, extra_data], ignore_index=True)
    else:
        extended_data = output_data
    return extended_data

# 读取并处理 PFT 数据
pft_data = [pd.read_csv(path) for path in output_paths]
extended_pft_data = [extend_and_fill(data, 612) for data in pft_data]
summed_data = sum(extended_pft_data)

# 计算 sumXp
sumXp = summed_data['Xp']

# 读取 Tiantong_Ecosystem_yearly 数据并计算 NEP，忽略列名中的空格
ecosystem_data = pd.read_csv('/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/output/Tiantong_Ecosystem_yearly.csv', skipinitialspace=True)
ecosystem_data['NEP'] = ecosystem_data['GPP'] - ecosystem_data['Rauto'] - ecosystem_data['Rh']

# 创建图形，1行2列
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5.5))

# 第一个图：NEP 和 sumXp 的时间序列图（主次 y 轴对调）
# 设置 NEP 为主轴，sumXp 为次轴
ax1.plot(range(1, 200), ecosystem_data['NEP'][:199], label='NEP', color='black', linestyle='--', linewidth=2.5)
ax1.set_xlabel('Forest age (years)', fontsize=24, labelpad=10)
ax1.set_ylabel('NEP', color='black', fontsize=24, labelpad=10)
ax1.set_ylim(-0.14, 1.25)
ax1.tick_params(axis='y', labelcolor='black')

# 次轴 y 轴：sumXp
ax1_right = ax1.twinx()
ax1_right.plot(range(1, 200), sumXp[1:200], label='sumXp', color='green', linewidth=2.5)
ax1_right.set_ylabel('Xp', color='green', fontsize=24, labelpad=10)
ax1_right.tick_params(axis='y', labelcolor='green', labelsize=20)
ax1_right.set_ylim(-10, 90)
ax1.tick_params(axis='both', labelsize=20)
# 设置坐标轴边框粗细
for spine in ax1.spines.values():
    spine.set_linewidth(2)  # 设置边框粗细


# 第二个图：sumXp 和 NEP 的相关性散点图（交换 x 和 y 轴）
ax2.scatter(ecosystem_data['NEP'][:199], sumXp[1:200], color='green', alpha=0.7)

# 计算线性拟合
slope, intercept = np.polyfit(ecosystem_data['NEP'][:199], sumXp[1:200], 1)
line = slope * ecosystem_data['NEP'][:199] + intercept
r_squablack = np.corrcoef(ecosystem_data['NEP'][:199], sumXp[1:200])[0, 1] ** 2

# 绘制趋势线
ax2.plot(ecosystem_data['NEP'][:199], line, color='black', lw=3, label=f' y={slope:.2f}x + {intercept:.2f}\n$R^2$={r_squablack:.2f}')
# 设置标签和图例
ax2.set_xlabel('NEP', fontsize=24, labelpad=10)
ax2.set_ylabel('Xp', fontsize=24, labelpad=10)
ax2.legend(fontsize=20)
ax2.tick_params(axis='both', labelsize=20)
# 设置坐标轴边框粗细
for spine in ax2.spines.values():
    spine.set_linewidth(1.5)  # 设置边框粗细


# 整体布局调整
plt.tight_layout()
plt.subplots_adjust(top=0.9)

# 保存图形
plt.savefig("/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/python/output/Figure7-XP&NEP.png",dpi=300)
plt.show()

# 计算 dydt
for data in extended_pft_data:
    data['dydt'] = data[['dydt1', 'dydt2', 'dydt3', 'dydt4', 'dydt5', 'dydt6', 'dydt7', 'dydt8', 'dydt9']].sum(axis=1)

# 求和得到 sumdydt
summed_data['dydt'] = sum(data['dydt'] for data in extended_pft_data)
sumdydt = summed_data['dydt']

# 读取 Tiantong_Ecosystem_yearly 数据并计算 NEP，忽略列名中的空格
ecosystem_data = pd.read_csv('/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/output/Tiantong_Ecosystem_yearly.csv', skipinitialspace=True)
ecosystem_data['NEP'] = ecosystem_data['GPP'] - ecosystem_data['Rauto'] - ecosystem_data['Rh']

# 创建图形，1行2列
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(8, 8.5))

# 左侧图：dydt 和 NEP 的时间序列图，共用一个 y 轴
ax1.plot(range(0, 200), sumdydt[:200], label=r"$X'(t)$", color='#9A7E6F', linewidth=2.5)
ax1.plot(range(0, 200), ecosystem_data['NEP'][:200], label='NEP', color='black', linestyle='--', linewidth=2.5)
ax1.set_xlabel('Forest age (years)', fontsize=24, labelpad=10)
ax1.set_ylabel(r'NEP (kg C m$^{-2}$ yr$^{-1}$)', fontsize=24, labelpad=12)
ax1.tick_params(axis='both', labelsize=24)
ax1.legend(fontsize=20, frameon=False)
# 添加阴影区域
ax1.axvspan(15, 25, color='grey', alpha=0.05)
ax1.axvspan(70, 80, color='grey', alpha=0.05)
ax1.axvspan(140, 150, color='grey', alpha=0.05)

# 设置坐标轴边框粗细
for spine in ax1.spines.values():
    spine.set_linewidth(2)  # 设置边框粗细


# 右侧图：dydt 和 NEP 的相关性图
ax2.scatter(sumdydt[:200], ecosystem_data['NEP'][:200], color='red', alpha=0.7)

# 计算线性拟合
slope, intercept = np.polyfit(sumdydt[:200], ecosystem_data['NEP'][:200], 1)
line = slope * sumdydt[:200] + intercept
r_squared = np.corrcoef(sumdydt[:200], ecosystem_data['NEP'][:200])[0, 1] ** 2

# 绘制趋势线
ax2.plot(sumdydt[:200], line, color='black', lw=3, label=f'y={slope:.2f}x + {intercept:.2f}\n$R^2$={r_squared:.2f}')

# 设置标签和图例
ax2.set_xlabel(r"$X'$", fontsize=24, labelpad=10)
ax2.set_ylabel('NEP', fontsize=24, labelpad=10)
ax2.legend(fontsize=20, frameon=False)
ax2.tick_params(axis='both', labelsize=20)
# 设置坐标轴边框粗细
for spine in ax2.spines.values():
    spine.set_linewidth(1.5)  # 设置边框粗细

# 调整布局
plt.tight_layout()
plt.subplots_adjust(top=0.9)

# 保存图形
plt.savefig("/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/python/output/Figure7_dydt_NEP.png",dpi=300)
plt.show()

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 创建图形
# 自定义颜色映射
# pft_colors = {
#     "EB-trees": "green",
#     "EB-shrubs": "#0099CC",
#     "EN-trees": 'grey',
#     "DB-trees": '#EE4266',
#     "DB-shrubs": 'orange'
# }

pft_colors = {
    "EB-trees": "#65B741",  # 绿色更明亮饱和
    "EB-shrubs": "#37B7C3",  # 蓝色更亮更饱和
    "EN-trees": "#999C9C",  # 灰色调更亮
    "DB-trees": "#FF5580",  # 红色饱和度增加，偏粉色
    "DB-shrubs": "#FF9D3D"   # 黄色更明亮饱和
}

# 5个PFT的顺序
# pft_data_list = [output_pft2, output_pft4, output_pft1, output_pft3, output_pft5]
pft_labels = ['EB-trees', 'EB-shrubs', 'EN-trees', 'DB-trees', 'DB-shrubs']

# 创建绘图
fig, ax = plt.subplots(figsize=(6, 5.5))

# 为每个 PFT 绘制 dydt 和 Xp 的相关性线
for data, label in zip(extended_pft_data, pft_labels):
    # 计算每个 PFT 文件的 dydt 和 Xp
    data['dydt'] = data[['dydt1', 'dydt2', 'dydt3', 'dydt4', 'dydt5', 'dydt6', 'dydt7', 'dydt8', 'dydt9']].sum(axis=1)
    dydt = data['dydt'][:200]
    Xp = data['Xp'][:200]

    # 绘制散点图并添加线性拟合
    ax.scatter(dydt, Xp, color=pft_colors[label], alpha=0.35,s=100)
    
    # 计算过原点的线性拟合（设置截距为 0）
    slope = np.sum(dydt * Xp) / np.sum(dydt ** 2)
    line = slope * dydt
    r_squared = (np.corrcoef(dydt, Xp)[0, 1] ** 2)

    # 绘制趋势线
    ax.plot(dydt, line, color=pft_colors[label], lw=4, 
            label=f'{label}: y={slope:.2f}x, $R^2$={r_squared:.2f}')

# 设置轴标签和图例
ax.set_xlabel(r"X$'$ (kg C m$^{-2}$ yr$^{-1})$", fontsize=20, labelpad=10)
ax.set_ylabel(r'Xp (kg C m$^{-2}$)', fontsize=20, labelpad=-5)
ax.legend(fontsize=11.5, loc='upper left',frameon=False)
ax.tick_params(axis='both', labelsize=20)
from matplotlib.ticker import MaxNLocator
ax.xaxis.set_major_locator(MaxNLocator(nbins=5))

# 设置坐标轴边框粗细
for spine in ax.spines.values():
    spine.set_linewidth(1.5)  # 设置边框粗细


# 调整布局和保存图形
plt.tight_layout()
plt.savefig("/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/python/output/Figure7_Tch.png",dpi=300)
plt.show()



# 计算每个 PFT 的 inverse_AK 和 dydt 列
for data in extended_pft_data:
    data['dydt'] = data[['dydt1', 'dydt2', 'dydt3', 'dydt4', 'dydt5', 'dydt6', 'dydt7', 'dydt8', 'dydt9']].sum(axis=1)
    data['inverse_AK'] = data[['inverse_AK1', 'inverse_AK2', 'inverse_AK3', 'inverse_AK4', 'inverse_AK5', 
                               'inverse_AK6', 'inverse_AK7', 'inverse_AK8', 'inverse_AK9']].sum(axis=1)

# 计算加权平均的 inverse_AK
summed_data['dydt'] = sum(data['dydt'] for data in extended_pft_data)
weighted_inverse_AK = sum(data['inverse_AK'] * data['dydt'] for data in extended_pft_data) / summed_data['dydt']

# 定义三个阶段的范围
ranges = [range(16, 27), range(71, 82), range(141, 152)]

# 计算三个阶段的平均值
avg_dydt = [summed_data['dydt'][r].mean() for r in ranges]
avg_inverse_AK = [weighted_inverse_AK[r].mean() for r in ranges]

# 绘制柱状图
stages = ['Early', 'Middle', 'Late']
colors = ['#CCDFD3', '#72A288', '#4B5760']
x = np.arange(len(stages))  # x轴位置

fig, axs = plt.subplots(1, 2, figsize=(6, 2.35), dpi=600)

# dydt的柱状图
axs[0].bar(x, avg_dydt, color=colors, edgecolor='black', width=0.5)
axs[0].set_xticks(x)
axs[0].tick_params(axis='x', labelbottom=False)  # 隐藏 x 轴标签
axs[0].tick_params(axis='y', labelsize=14)
axs[0].set_ylabel(r'kg C m$^{-2}$ yr$^{-1}$', fontsize=16)
axs[0].set_title(r"$X'(t)$", fontsize=24)

# inverse_AK的柱状图
axs[1].bar(x, avg_inverse_AK, color=colors, edgecolor='black', width=0.5)
axs[1].set_xticks(x)
axs[1].tick_params(axis='x', labelbottom=False)  # 隐藏 x 轴标签
axs[1].tick_params(axis='y', labelsize=14)
axs[1].set_ylabel(r'years', fontsize=16)
axs[1].set_title(r"$\tau_{ch}$", fontsize=24)
axs[1].set_ylim(0,90)

# 设置每个子图的边框粗细
for ax in axs:
    for spine in ax.spines.values():
        spine.set_linewidth(1.5)  # 设置边框粗细

for ax in axs:
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

# 调整布局并显示图形
plt.tight_layout()
plt.savefig("/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/python/output/Figure9_Tch_X'.png",dpi=300)
plt.show()

# 定义三个阶段的范围
ranges = [range(16, 27), range(71, 82), range(141, 152)]
stages = ['Early', 'Middle', 'Late']
colors = ['#CCDFD3', '#72A288', '#4B5760']

# 创建图形
fig, ax = plt.subplots(figsize=(2.4, 2.3), dpi=600)

# 绘制每个阶段的散点图和过原点的拟合线
for r, stage, color in zip(ranges, stages, colors):
    stage_sumdydt = sumdydt[r]
    stage_sumXp = sumXp[r]
    
    # 绘制散点图
    ax.scatter(stage_sumdydt, stage_sumXp, color=color, label=stage,edgecolor='none', alpha=0.7, s=50)
    
    # 计算过原点的线性拟合斜率
    slope = np.sum(stage_sumdydt * stage_sumXp) / np.sum(stage_sumdydt ** 2)
    line = slope * np.array([0, max(stage_sumdydt)])
    
    # 绘制趋势线
    ax.plot([0, max(stage_sumdydt)], line, color=color, lw=3, linestyle='-', label=f'{stage} slope={slope:.2f}')

# 设置轴标签和图例
ax.set_xlabel(r"$X'$   ", fontsize=14)
ax.set_ylabel("Xp", fontsize=14)
#ax.legend(fontsize=10, frameon=False)
ax.tick_params(axis='both', labelsize=12)
# 在图中添加标题，位置为 (0.5, 0.8)
ax.text(0.5, 0.95, r"$\tau_{ch}$", transform=ax.transAxes, fontsize=22, ha='center')

from matplotlib.ticker import MaxNLocator
ax.xaxis.set_major_locator(MaxNLocator(nbins=4))

# 设置坐标轴边框粗细
for spine in ax.spines.values():
    spine.set_linewidth(1.5)

ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

# 调整布局和保存图形
plt.tight_layout()
plt.savefig("/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/python/output/Figure9_Tch.png",dpi=300)
plt.show()

# 扩展和填充数据框的函数
def extend_and_fill(output_data, rows_to_fill):
    current_rows = output_data.shape[0]
    rows_to_add = rows_to_fill - current_rows
    if rows_to_add > 0:
        extra_data = pd.DataFrame(np.zeros((rows_to_add, output_data.shape[1])), columns=output_data.columns)
        extended_data = pd.concat([output_data, extra_data], ignore_index=True)
    else:
        extended_data = output_data
    return extended_data

# 读取并处理 PFT 数据
pft_data = [pd.read_csv(path) for path in output_paths]
extended_pft_data = [extend_and_fill(data, 612) for data in pft_data]

# 计算每个 PFT 的 dydt 和 inverse_AK
for data in extended_pft_data:
    data['dydt'] = data[['dydt1', 'dydt2', 'dydt3', 'dydt4', 'dydt5', 'dydt6', 'dydt7', 'dydt8', 'dydt9']].sum(axis=1)
    data['inverse_AK'] = data[['inverse_AK1', 'inverse_AK2', 'inverse_AK3', 'inverse_AK4', 'inverse_AK5',
                               'inverse_AK6', 'inverse_AK7', 'inverse_AK8', 'inverse_AK9']].sum(axis=1)

# 创建图形，2行1列
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(8, 7), dpi=300)

# 第一个图：5个 PFT 的 dydt 曲线图
for data, label in zip(extended_pft_data, pft_labels):
    dydt = data['dydt'][:200]
    ax1.plot(range(1, 201), dydt, label=label, color=pft_colors[label], linewidth=2.5)

ax1.set_ylabel(r"$X'$ (kg C m$^{-2}$ yr$^{-1}$)", fontsize=22)
ax1.tick_params(axis='both', labelsize=20)

# 第二个图：5个 PFT 的 inverse_AK 曲线图
for data, label in zip(extended_pft_data, pft_labels):
    inverse_AK = data['inverse_AK'][:200]
    ax2.plot(range(1, 201), inverse_AK, label=label, color=pft_colors[label], linewidth=2.5)

ax2.set_xlabel('Forest age (years)', fontsize=22)
ax2.set_ylabel(r'$\tau_{ch}$ (years)', fontsize=22)
ax2.tick_params(axis='both', labelsize=20)
ax2.set_ylim(0,200)

# 设置每个子图的边框粗细
for ax in [ax1, ax2]:
    for spine in ax.spines.values():
        spine.set_linewidth(2)

# 调整布局并保存图形
plt.tight_layout()
plt.savefig("/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/python/output/Figure8bc_inverseAK.png",dpi=300)
plt.show()

# 5个PFT的顺序和标签
pft_labels = ['EB-trees', 'EB-shrubs', 'EN-trees', 'DB-trees', 'DB-shrubs']

# 扩展和填充数据框的函数
def extend_and_fill(output_data, rows_to_fill):
    current_rows = output_data.shape[0]
    rows_to_add = rows_to_fill - current_rows
    if rows_to_add > 0:
        extra_data = pd.DataFrame(np.zeros((rows_to_add, output_data.shape[1])), columns=output_data.columns)
        extended_data = pd.concat([output_data, extra_data], ignore_index=True)
    else:
        extended_data = output_data
    return extended_data

# 读取并处理 PFT 数据
pft_data = [pd.read_csv(path) for path in output_paths]
extended_pft_data = [extend_and_fill(data, 612) for data in pft_data]

# 计算每个 PFT 的 dydt
for data in extended_pft_data:
    data['dydt'] = data[['dydt1', 'dydt2', 'dydt3', 'dydt4', 'dydt5', 'dydt6', 'dydt7', 'dydt8', 'dydt9']].sum(axis=1)

# 创建图形，2行1列
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(8, 7.5), dpi=300)
pft_colors = {
    "EB-trees": "#65B741",  # 绿色更明亮饱和
    "EB-shrubs": "#37B7C3",  # 蓝色更亮更饱和
    "EN-trees": "#999C9C",  # 灰色调更亮
    "DB-trees": "#FF5580",  # 红色饱和度增加，偏粉色
    "DB-shrubs": "#FF9D3D"   # 黄色更明亮饱和
}

# 第一个图：5个 PFT 的 dydt 曲线图
for data, label in zip(extended_pft_data, pft_labels):
    dydt = data['dydt'][:200]
    ax1.plot(range(1, 201), dydt, label=label, color=pft_colors[label], linewidth=2.5)

#ax1.set_xlabel('Forest age (years)', fontsize=22)
ax1.set_ylabel(r"X$'$ (kg C m$^{-2}$ yr$^{-1}$)", fontsize=24,labelpad=15)
#ax1.set_title('dydt for 5 PFTs', fontsize=16)
ax1.legend(fontsize=14,  ncol=2, loc='lower right', bbox_to_anchor=(1.02, 0.63), frameon=False)
ax1.tick_params(axis='both', labelsize=24)# 添加阴影区域
ax1.axvspan(15, 25, color='grey', alpha=0.05)
ax1.axvspan(70, 80, color='grey', alpha=0.05)
ax1.axvspan(140, 150, color='grey', alpha=0.05)

# 设置坐标轴范围
ax1.set_ylim(-0.1, 1.2)

# 第二个图：5个 PFT 的 Xp 曲线图
for data, label in zip(extended_pft_data, pft_labels):
    Xp = data['Xp'][:200]
    ax2.plot(range(1, 201), Xp, label=label, color=pft_colors[label], linewidth=2.5)

ax2.set_xlabel('Forest age (years)', fontsize=30,labelpad=10)
ax2.set_ylabel('Xp (kg C m$^{-2}$)', fontsize=25,labelpad=20)
#ax2.set_title('Xp for 5 PFTs', fontsize=16)
#ax2.legend(fontsize=18)
ax2.tick_params(axis='both', labelsize=24)
# 添加阴影区域
ax2.axvspan(15, 25, color='grey', alpha=0.05)
ax2.axvspan(70, 80, color='grey', alpha=0.05)
ax2.axvspan(140, 150, color='grey', alpha=0.05)
from matplotlib.ticker import MaxNLocator
ax2.xaxis.set_major_locator(MaxNLocator(nbins=5))

# 设置每个子图的边框粗细
for ax in [ax1, ax2]:
    for spine in ax.spines.values():
        spine.set_linewidth(2)

# 调整布局并保存图形
plt.tight_layout()
plt.savefig("/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/python/output/Figure8bc.png",dpi=300)
plt.show()

import numpy as np
import pandas as pd

# 计算每个PFT的dydt面积积分，并计算总的dydt的积分
dydt_areas = []
for data in extended_pft_data:
    dydt = data['dydt'][:200]  # 取前200年数据
    dydt_area = np.trapz(dydt, range(1, 201))  # 使用梯形法计算面积积分
    dydt_areas.append(dydt_area)

# 计算所有PFT的总dydt积分
total_dydt_area = sum(dydt_areas)

# 计算每个PFT的积分占总积分的百分比
percent_contrib = [(area / total_dydt_area) * 100 for area in dydt_areas]

# 打印结果
for label, percent in zip(pft_labels, percent_contrib):
    print(f"Relative Contribution of {label}: {percent:.2f}%")
