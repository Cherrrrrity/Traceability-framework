import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 文件路径
output_pft1_path = '/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/matrix/output/[1]pft1-output.csv'
output_pft2_path = '/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/matrix/output/[1]pft2-output.csv'
output_pft3_path = '/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/matrix/output/[1]pft3-output.csv'
output_pft4_path = '/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/matrix/output/[1]pft4-output.csv'
output_pft5_path = '/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/matrix/output/[1]pft5-output.csv'

# 读取数据
output_pft1 = pd.read_csv(output_pft1_path)
output_pft2 = pd.read_csv(output_pft2_path)
output_pft3 = pd.read_csv(output_pft3_path)
output_pft4 = pd.read_csv(output_pft4_path)
output_pft5 = pd.read_csv(output_pft5_path)

# 扩展和填充数据框的函数
def extend_and_fill(output_data, rows_to_fill):
    current_rows = output_data.shape[0]
    rows_to_add = rows_to_fill - current_rows
    if rows_to_add > 0:
        extra_data = pd.DataFrame(np.zeros((rows_to_add, output_data.shape[1])), columns=output_data.columns)
        extended_data = pd.concat([output_data, extra_data], ignore_index=True)
    else:
        extended_data = output_data
    return extended_data

# 处理所有pft的数据
output_pft1 = extend_and_fill(output_pft1, 612)
output_pft2 = extend_and_fill(output_pft2, 612)
output_pft3 = extend_and_fill(output_pft3, 612)
output_pft4 = extend_and_fill(output_pft4, 612)
output_pft5 = extend_and_fill(output_pft5, 612)

# 对5个数据框在对应位置加和
summed_data = output_pft1 + output_pft2 + output_pft3 + output_pft4 + output_pft5
# 打印summed_data第201行的X列
print(summed_data.loc[150, 'X'])

# 创建 Figure3.png 的绘图
fig, ax = plt.subplots(1, figsize=(10, 5), dpi=600)

# 绘制 X 和 Xc 的线图
ax.plot(range(1, len(summed_data) + 1), summed_data['Xc'], label='Xc', color='#72A288', linestyle='-', linewidth=3)
ax.plot(range(1, len(summed_data) + 1), summed_data['X'], label='X', color='black', linewidth=4)

# 添加 Xc 和 X 之间的阴影区域（正值显示红色，负值显示蓝色）
ax.fill_between(range(1, len(summed_data) + 1), summed_data['X'], summed_data['Xc'], 
                where=(summed_data['Xc'] > summed_data['X']), color='#72A288', alpha=1, label='Xp')
ax.fill_between(range(1, len(summed_data) + 1), summed_data['X'], summed_data['Xc'], 
                where=(summed_data['Xc'] < summed_data['X']), color='#72A288', alpha=1)

# 设置坐标轴范围
ax.set_ylim(0, 130)
ax.set_xlim(1, 200)

# 添加阴影区域
ax.axvspan(15, 25, color='grey', alpha=0.05, zorder=0)
ax.axvspan(70, 80, color='grey', alpha=0.05, zorder=0)
ax.axvspan(140, 150, color='grey', alpha=0.05, zorder=0)

# 设置坐标轴标签和字体大小
ax.set_xlabel('Forest age (years)', fontsize=24, labelpad=10)
ax.set_ylabel(r'C storage (kg C m$^{-2}$)', fontsize=24)

# 设置坐标轴边框粗细
for spine in ax.spines.values():
    spine.set_linewidth(1.5)

# 设置图例字体大小
ax.legend(frameon=False, fontsize=20, loc='lower right')
ax.tick_params(axis='both', labelsize=20)

# 调整布局并保存图像
plt.tight_layout()
plt.savefig("/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/python/output/Figure5a.png")
plt.show()

# 创建子图
fig, axs = plt.subplots(5, 1, figsize=(7, 8), dpi=300, sharex=True)
fig.subplots_adjust(left=0.05, right=0.9, top=0.95, bottom=0.05, hspace=0.2)

# 绘制每个 output_pft 的 X 和 Xc，并根据差值颜色填充阴影
for i, (output_pft, title) in enumerate(zip(
    [output_pft2, output_pft4, output_pft1, output_pft3, output_pft5],
    ['(b) EBT', 
     '(c) ES', 
     '(d) ENT', 
     '(e) DBT', 
     '(f) DS'])):
    
    # 过滤数值为0的数据点
    output_pft = output_pft[output_pft['X'] != 0]
    x_values = range(1, len(output_pft) + 1)
    
    # 绘制 X 和 Xc 的曲线
    # axs[i].plot(x_values, output_pft['Xc'], label='Xc', color='black', linestyle='--', linewidth=1)
    axs[i].plot(x_values, output_pft['X'], label='X', color='black', linewidth=2.5)
    
    # 填充 X 和 Xc 之间的差值区域（正值为红色，负值为蓝色）
    axs[i].fill_between(x_values, output_pft['X'], output_pft['Xc'], 
                        where=(output_pft['Xc'] > output_pft['X']), color='#FFB2B2', alpha=1, label='Xp (positive)')#FFB2B2
    axs[i].fill_between(x_values, output_pft['X'], output_pft['Xc'], 
                        where=(output_pft['Xc'] < output_pft['X']), color='#B2B2FF', alpha=1, label='Xp (negative)')
    
    axs[i].set_xlim(1, 200)
    axs[i].axhline(0, linestyle='--', color='darkgrey', linewidth=1)
    
    # 设置坐标轴边框粗细
    for spine in axs[i].spines.values():
        spine.set_linewidth(1)

    # 最后一个子图设置 X 轴标签
    if i == 4:
        axs[i].set_xlabel('Year', fontsize=12)

    # 移动 y 轴标签和刻度到右侧
    axs[i].yaxis.set_label_position("right")
    axs[i].yaxis.tick_right()

    # 设置每个子图的标题
    axs[i].text(0.01, 0.85, title, transform=axs[i].transAxes, fontsize=12)

    # 坐标标尺朝内
    axs[i].tick_params(axis='both', direction='in')

    # 最后一个子图显示图例且去除边框
    if i == 4:
        axs[i].legend(frameon=False)

# 设置 x 轴刻度标签
axs[4].set_xticks(np.arange(0, 201, 25))
axs[4].set_xticklabels(np.arange(0, 201, 25))

# 保存并显示图形
#plt.savefig("/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/python/output/Figure5_5pfts.png")

# 对5个数据框在对应位置加和
summed_data = output_pft1 + output_pft2 + output_pft3 + output_pft4 + output_pft5

# 计算三个阶段的平均值
ranges = [range(16, 27), range(71, 82), range(141, 152)]
avg_X = [summed_data['X'][r].mean() for r in ranges]
avg_Xc = [summed_data['Xc'][r].mean() for r in ranges]
avg_Xp = [(summed_data['Xc'][r] - summed_data['X'][r]).mean() for r in ranges]

# 创建柱状图
stages = ['Early', 'Middle', 'Late']
colors = ['#CCDFD3', '#72A288', '#4B5760']
x = np.arange(len(stages))  # x轴位置

fig, axs = plt.subplots(1, 3, figsize=(9, 2.3), dpi=600)

# X的柱状图
axs[0].bar(x, avg_X, color=colors, edgecolor='black', width=0.5)
axs[0].set_xticks(x)
axs[0].tick_params(axis='x', labelbottom=False)  # 隐藏 x 轴标签
axs[0].tick_params(axis='y', labelsize=14)
axs[0].set_ylabel(r'kg C m$^{-2}$', fontsize=16)
axs[0].set_title(r"$X(t)$", fontsize=22)

# Xc的柱状图
axs[1].bar(x, avg_Xc, color=colors, edgecolor='black', width=0.5)
axs[1].set_xticks(x)
axs[1].tick_params(axis='x', labelbottom=False)  # 隐藏 x 轴标签
axs[1].tick_params(axis='y', labelsize=14)
axs[1].set_ylabel(r'kg C m$^{-2}$', fontsize=16)
axs[1].set_title(r"$Xc(t)$", fontsize=22)

# Xp的柱状图
axs[2].bar(x, avg_Xp, color=colors, edgecolor='black', width=0.5)
axs[2].set_xticks(x)
axs[2].tick_params(axis='x', labelbottom=False)  # 隐藏 x 轴标签
axs[2].tick_params(axis='y', labelsize=14)
axs[2].set_ylabel(r'kg C m$^{-2}$', fontsize=16)
axs[2].set_title(r"$Xp(t)$", fontsize=22)

# 设置每个子图的边框粗细
for ax in axs:
    for spine in ax.spines.values():
        spine.set_linewidth(1.5)  # 设置边框粗细

# 隐藏每个子图的顶部和右侧边框
for ax in axs:
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.set_ylim(0,100)

# 调整布局并显示图形
plt.tight_layout()
plt.savefig("/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/python/output/Figure9_X&Xc&Xp.png")
plt.show()