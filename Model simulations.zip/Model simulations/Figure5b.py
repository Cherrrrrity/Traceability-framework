import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import matplotlib.cm as cm

# 文件路径
output_pft1_path = '/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/output/pft1-output.csv'
output_pft2_path = '/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/output/pft2-output.csv'
output_pft3_path = '/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/output/pft3-output.csv'
output_pft4_path = '/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/output/pft4-output.csv'
output_pft5_path = '/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/output/pft5-output.csv'

# 读取数据
output_pft1 = pd.read_csv(output_pft1_path)
output_pft2 = pd.read_csv(output_pft2_path)
output_pft3 = pd.read_csv(output_pft3_path)
output_pft4 = pd.read_csv(output_pft4_path)
output_pft5 = pd.read_csv(output_pft5_path)

# 扩展和填充数据框的函数
def extend_and_fill(output_data, rows_to_fill):
    current_rows = output_data.shape[0]
    rows_to_add = rows_to_fill - current_rows
    
    # 如果需要添加的行数大于0才执行以下操作
    if rows_to_add > 0:
        extra_data = pd.DataFrame(np.zeros((rows_to_add, output_data.shape[1])), columns=output_data.columns)
        extended_data = pd.concat([output_data, extra_data], ignore_index=True)
    else:
        # 如果不需要添加行，则直接返回输入数据框
        extended_data = output_data
    return extended_data

# 处理所有pft的数据
num_years = 612
years = np.arange(1, num_years + 1)

# 计算总和并归一化为相对贡献
total_x = output_pft1['X'] + output_pft2['X'] + output_pft3['X'] + output_pft4['X'] + output_pft5['X']
output_pft1['X'] = (output_pft1['X'] / total_x) * 100
output_pft2['X'] = (output_pft2['X'] / total_x) * 100
output_pft3['X'] = (output_pft3['X'] / total_x) * 100
output_pft4['X'] = (output_pft4['X'] / total_x) * 100
output_pft5['X'] = (output_pft5['X'] / total_x) * 100

# 绘制堆叠面积图
plt.figure(figsize=(10, 5))
# 获取 "viridis" 调色盘的颜色
viridis_colors =['#65B741','#37B7C3','#999C9C' ,'#FF5580', '#FF9D3D']

plt.stackplot(
    years,
    output_pft2['X'],
    output_pft4['X'],
    output_pft1['X'],
    output_pft3['X'],
    output_pft5['X'],
    labels=['EB-trees', 'EB-shrubs', 'EN-trees', 'DB-trees', 'DB-shrubs'],
    colors=viridis_colors,
    edgecolor='black'
)

plt.xlabel('Forest age (years)', fontsize=24, labelpad=10)
plt.xlim(1, 200)
plt.ylim(0, 100)
# 添加阴影区域
plt.axvspan(15, 25, color='grey', alpha=0.05, zorder=1)
plt.axvspan(70, 80, color='grey', alpha=0.05, zorder=1)
plt.axvspan(140, 150, color='grey', alpha=0.05, zorder=1)
plt.tick_params(axis='both', labelsize=20) 
plt.ylabel('Relative Contribution (%)', fontsize=24)
plt.legend(loc='lower right', fontsize=20)
ax = plt.gca()  # Get the current Axes instance
for spine in ax.spines.values():
    spine.set_linewidth(1.5)
plt.tight_layout()
plt.show()

# Save the combined figure
plt.savefig("/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/python/output/Figure5_pfts.png")

# 计算1到200年期间每个pft的面积积分（使用梯形法）
area_pft1 = np.trapz(output_pft1['X'][:200], years[:200])
area_pft2 = np.trapz(output_pft2['X'][:200], years[:200])
area_pft3 = np.trapz(output_pft3['X'][:200], years[:200])
area_pft4 = np.trapz(output_pft4['X'][:200], years[:200])
area_pft5 = np.trapz(output_pft5['X'][:200], years[:200])

# 计算总面积
total_area = area_pft1 + area_pft2 + area_pft3 + area_pft4 + area_pft5

# 计算每个pft的相对贡献百分比
percent_pft1 = (area_pft1 / total_area) * 100
percent_pft2 = (area_pft2 / total_area) * 100
percent_pft3 = (area_pft3 / total_area) * 100
percent_pft4 = (area_pft4 / total_area) * 100
percent_pft5 = (area_pft5 / total_area) * 100

# 输出每个PFT的相对贡献百分比
print(f"Relative Contribution of PFT1: {percent_pft1:.2f}%")
print(f"Relative Contribution of PFT2: {percent_pft2:.2f}%")
print(f"Relative Contribution of PFT3: {percent_pft3:.2f}%")
print(f"Relative Contribution of PFT4: {percent_pft4:.2f}%")
print(f"Relative Contribution of PFT5: {percent_pft5:.2f}%")
