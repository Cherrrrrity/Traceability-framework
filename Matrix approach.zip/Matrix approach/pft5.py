from GeneralModel import GeneralModel
import numpy as np
import matplotlib.pyplot as plt
import sys
import pandas as pd

if __name__ == '__main__':

    output_folder = '/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/matrix/output/'
#0.读取CSV文件
    data = pd.read_csv('/home/chen_lt/Model/BiomeE/13.BiomeESS2.03-Feb.9/output/input_pft5.csv')

#1.u(t)
    input_fluxes = np.array(data['Cinput'].values.tolist())

#2.B(t)
    BB = np.array(data['b1'].values.tolist() +
                  data['b2'].values.tolist() +
                  data['b3'].values.tolist() +
                  data['b4'].values.tolist() +
                  data['b5'].values.tolist() +
                  data['b6'].values.tolist() +
                  data['b7'].values.tolist() +
                  data['b8'].values.tolist() +
                  data['b9'].values.tolist()).reshape([9,612])   # allocation 
    B = np.zeros((612, 9))
    for i in range(612):
       B[i, :] = BB[:, i] #转置矩阵

#3.A
    f54 = 0.047077292; f24 = 0.1-0.1*f54; f34 = 0.1-0.1*f54; f51 = 0.02/0.03; f61 = 1-f51; f52 = 1;
    f63 = 1; f78 = 0.000641558; f79 = 0.000216234; f85 = 1; f96 = 1;
    A = np.array([-1, 0, 0, 0, 0, 0, 0, 0, 0,
                0, -1, 0, f24, 0, 0, 0, 0, 0,
                0, 0, -1, f34, 0, 0, 0, 0, 0,
                0, 0, 0, -1, 0, 0, 0, 0, 0,
                f51, f52, 0, f54, -1, 0, 0, 0, 0,
                f61, 0, f63, 0, 0, -1, 0, 0, 0,
                0, 0, 0, 0, 0, 0, -1, f78, f79,
                0, 0, 0, 0, f85, 0, 0, -1, 0,
                0, 0, 0, 0, 0, f96, 0, 0, -1]).reshape([9,9])   # tranfer

#4.K(t)
    k1 = np.array(data['K1'].values.tolist())
    k2 = np.array(data['K2'].values.tolist())
    k3 = np.array(data['K3'].values.tolist())
    k4 = np.array(data['K4'].values.tolist())
    k5 = np.array(data['K5'].values.tolist())
    k6 = np.array(data['K6'].values.tolist()) 
    k7 = np.array(data['K7'].values.tolist())   
    k8 = np.array(data['K8'].values.tolist())
    k9 = np.array(data['K9'].values.tolist())
    temp = [k1, k2, k3, k4, k5, k6, k7, k8, k9]

    K = np.zeros(81*612).reshape([9, 9, 612])

    for i in range(0, 9):
        K[i,i,:] = temp[i]
         
    #Unit of turnover rate from day^-1 to second^-1  
    #1 day = 86400 seconds
    #K = np.multiply(K, 1/(365*86400))

    #environmental scalar
    #Xi1 = 1; Xi2 = 1; Xi3 = 1; Xi4 = 1;
    #Xi5 = 1; Xi6 = 0.243; Xi7 = 0.243; Xi8 = 0.243;
    #envi = [Xi1, Xi2, Xi3, Xi4, Xi5, Xi6, Xi7, Xi8]
    #xi = np.zeros(64).reshape([8, 8])
    #for i in range(0, 8):
    # xi[i][i] = envi[i]
 
#6.initial pools
    nyear = 612   #number of simulation years 
    times = np.linspace(0, nyear, num = nyear) #时间步长（start，stop，num） nyear*365*86400
    iv_list = [0,0,0.002,0,0,0,0,0,0]    
    mod = GeneralModel(times, B, A, K, iv_list, input_fluxes)
    res = mod.get_x()
    df = mod.get_x_df()

#7.Figure
    fig = plt.figure(12*4, figsize=(15, 13))
    plt.subplots_adjust(left  = 0.1, right = 0.9, bottom = 0.05, top = 0.95, wspace =0.3, hspace =0.4)
    x = list(range(1,nyear + 1, 1))
    pool_names = ["leaves", "fine roots", "wood", "seed", "metabolic litter", "structural litter", "microbial litter", "fast SOM", "slow SOM"] 

    for i in range(1, 5):
        for j in range(1, 4):
            if ((i-1) * 3 + j) > 9 :
                break
            ax = plt.subplot(4, 3, (i-1) * 3 + j)
            ax.plot(x, res[(i-1) * 3 + j - 1,:],color='#FF7777')
            plt.xlabel("year", fontsize = 14)
            plt.title(pool_names[(i-1) * 3 + (j-1)],fontsize=18)
            plt.ylabel(" pool ($kg C m^{-2}$)", fontsize = 14)
    ax = plt.subplot(4, 3, 10)
    ax.plot(x, df["C_input"], label = "carbon input",color='#399918')
    plt.xlabel("year", fontsize = 14)
    plt.title('NPP',fontsize=18)
    plt.ylabel("C input ($kg C m^{-2}$)", fontsize = 14)
    
    ax = plt.subplot(4, 3, 11)
    ax.plot(x, df["Tres"], label = "residence time",color='#006BFF')
    plt.xlabel("year", fontsize = 14)
    plt.title(r'$\tau_N$',fontsize=18)
    plt.ylabel(r'$\tau_N$', fontsize = 14)

    ax = plt.subplot(4, 3, 12)
    ax.plot(x, df["Xc"], color = "black", label = "C storage capacity")
    ax.plot(x, df["Xp"], color = "blue", label = "C storage potential")
    ax.plot(x, df["X"], color = "red", label = "C storage")
    plt.xlabel("year", fontsize = 14)
    plt.ylabel("($kg C m^{-2}$)", fontsize = 14)
    plt.title('')
    plt.legend()
    plt.savefig(output_folder + "/[2]pft5-result" + ".png", dpi = 500)
    #plt.show()

    print(res[:,nyear-1])   # print result of the last year

 # 添加绘图逻辑
# 绘制 X_vals, Xc_vals, Xp_vals
fig, axs = plt.subplots(3, 3, figsize=(15, 10))
fig.suptitle("Carbon storage, capacity, potential", fontsize=22)

for i, pool_name in enumerate(pool_names):
    ax = axs[i // 3, i % 3]
    ax.plot(df[f'X{i+1}'], label='X',color='black')
    ax.plot(df[f'Xc{i+1}'], label='Xc',color='blue')
    ax.plot(df[f'Xp{i+1}'], label='Xp',color='red')
    ax.set_title(pool_name,fontsize=18)
    ax.set_xlabel("Year",fontsize=18)
    ax.set_ylabel(r"Value (kg C m$^{-2}$)",fontsize=18)
    ax.legend()

plt.tight_layout(rect=[0, 0, 1, 0.96])

plt.savefig(output_folder + "/[3]pft5-X_Xc_Xp.png")

# 绘制 matrix_Residences 和 inverse_AKs
fig, axs = plt.subplots(3, 3, figsize=(15, 10))
fig.suptitle(r'$\tau_N$', fontsize=22)

for i, pool_name in enumerate(pool_names):
    ax = axs[i // 3, i % 3]
    ax.plot(df[f'matrix_Residence{i+1}'], label=r'$\tau_N$',color='#4379F2')
    ax.set_title(pool_name,fontsize=18)
    ax.set_xlabel("Year",fontsize=18)
    ax.set_ylabel(r'$\tau_N$ (years)',fontsize=18)
    ax.legend()

plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig(output_folder + "/[4]pft5-matrix_Residences.png")

# 绘制 matrix_Residences 和 inverse_AKs
fig, axs = plt.subplots(3, 3, figsize=(15, 10))
fig.suptitle(r'$\tau_ch$', fontsize=22)

for i, pool_name in enumerate(pool_names):
    ax = axs[i // 3, i % 3]
    ax.plot(df[f'inverse_AK{i+1}'], label=r'$\tau_ch$',color='#FF885B')
    ax.plot(df[f'matrix_Residence{i+1}'], label=r'$\tau_N$',color='#4379F2')
    ax.set_title(pool_name,fontsize=18)
    ax.set_xlabel("Year",fontsize=18)
    ax.set_ylabel(r'$\tau_ch$ (years)',fontsize=18)
    ax.legend()

plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig(output_folder + "/[4.1]pft5-inverse_AKs.png")

# 绘制 dydt_vals
fig, axs = plt.subplots(3, 3, figsize=(15, 10))
fig.suptitle(r"$X'(t)$", fontsize=22)

for i, pool_name in enumerate(pool_names):
    ax = axs[i // 3, i % 3]
    ax.plot(df[f'dydt{i+1}'], label=r"$X'(t)$",color='green')
    ax.set_title(pool_name,fontsize=18)
    ax.set_xlabel("Year",fontsize=18)
    ax.set_ylabel("Value",fontsize=18)
    ax.legend()

plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig(output_folder + "/[5]pft5-dydt.png")


# 导出到 CSV 文件
mod.write_output(output_folder + "/[1]pft5-output.csv")

    